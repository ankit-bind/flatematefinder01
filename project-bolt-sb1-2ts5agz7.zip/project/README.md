# Roommate Finder Application

A full-stack web application to help users find compatible roommates based on location, budget, and lifestyle preferences.

## Features

- User authentication (signup, login, logout) with JWT
- Create and manage your roommate profile
- Search for potential roommates with filtering options
- View detailed roommate profiles
- Responsive design that works on all devices

## Tech Stack

### Frontend
- React with TypeScript
- React Router for navigation
- Tailwind CSS for styling
- Axios for API requests
- Lucide React for icons

### Backend
- Node.js with Express
- MongoDB with Mongoose for data storage
- JWT for authentication
- RESTful API design

## Getting Started

### Prerequisites

- Node.js (v14+)
- MongoDB (local or Atlas)

### Installation

1. Clone the repository:
```
git clone https://github.com/yourusername/roommate-finder.git
cd roommate-finder
```

2. Install dependencies:
```
npm install
```

3. Create a `.env` file in the root directory based on the `.env.example` file:
```
PORT=5000
NODE_ENV=development
MONGODB_URI=mongodb://localhost:27017/roommate-finder
JWT_SECRET=your_jwt_secret_key
JWT_EXPIRE=30d
```

4. Start the development server:
```
npm run dev
```

This will start both the frontend and backend servers concurrently.

## Project Structure

```
roommate-finder/
├── client/           # Frontend React application
│   ├── src/
│   │   ├── components/   # Reusable UI components
│   │   ├── pages/        # Page components
│   │   ├── context/      # React context providers
│   │   └── types/        # TypeScript type definitions
│   └── public/       # Static assets
├── server/           # Backend Node.js application
│   ├── config/       # Configuration files
│   ├── controllers/  # Route controllers
│   ├── middleware/   # Express middleware
│   ├── models/       # Mongoose models
│   └── routes/       # Express routes
└── .env              # Environment variables
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register a new user
- `POST /api/auth/login` - Login a user
- `GET /api/auth/me` - Get current user profile

### Profiles
- `POST /api/profiles` - Create or update a profile
- `GET /api/profiles/me` - Get current user's profile
- `GET /api/profiles` - Get all profiles (with filters)
- `GET /api/profiles/:id` - Get profile by ID

## License

MIT