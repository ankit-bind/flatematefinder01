import express from 'express';
import { 
  createProfile, 
  getMyProfile, 
  getProfiles, 
  getProfileById 
} from '../controllers/profileController.js';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

router.route('/')
  .post(protect, createProfile)
  .get(getProfiles);

router.get('/me', protect, getMyProfile);
router.get('/:id', getProfileById);

export default router;