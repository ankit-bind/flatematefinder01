import express from 'express';
import { protect } from '../middleware/authMiddleware.js';

const router = express.Router();

// These routes would be expanded in a full implementation
router.get('/', (req, res) => {
  res.json({ message: 'User routes available' });
});

export default router;