import Profile from '../models/profileModel.js';

// @desc    Create or update user profile
// @route   POST /api/profiles
// @access  Private
export const createProfile = async (req, res) => {
  try {
    const {
      bio,
      age,
      gender,
      occupation,
      location,
      budget,
      moveInDate,
      preferences,
      lifestyle,
      photos
    } = req.body;

    // Check if profile exists
    let profile = await Profile.findOne({ user: req.user._id });

    if (profile) {
      // Update profile
      profile = await Profile.findOneAndUpdate(
        { user: req.user._id },
        { 
          bio,
          age,
          gender,
          occupation,
          location,
          budget,
          moveInDate,
          preferences,
          lifestyle,
          photos
        },
        { new: true }
      );
    } else {
      // Create profile
      profile = await Profile.create({
        user: req.user._id,
        bio,
        age,
        gender,
        occupation,
        location,
        budget,
        moveInDate,
        preferences,
        lifestyle,
        photos
      });
    }

    res.status(201).json(profile);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// @desc    Get user profile
// @route   GET /api/profiles/me
// @access  Private
export const getMyProfile = async (req, res) => {
  try {
    const profile = await Profile.findOne({ user: req.user._id }).populate('user', ['name', 'email', 'avatar']);

    if (!profile) {
      return res.status(404).json({ error: 'Profile not found' });
    }

    res.json(profile);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// @desc    Get all profiles
// @route   GET /api/profiles
// @access  Public
export const getProfiles = async (req, res) => {
  try {
    const { city, budget, gender, pets, smoking } = req.query;
    const query = { active: true };

    // Add filters if they exist
    if (city) query['location.city'] = { $regex: city, $options: 'i' };
    if (budget) query['budget.max'] = { $lte: Number(budget) };
    if (gender) query['gender'] = gender;
    if (pets !== undefined) query['preferences.pets'] = pets === 'true';
    if (smoking !== undefined) query['preferences.smoking'] = smoking === 'true';

    const profiles = await Profile.find(query)
      .populate('user', ['name', 'avatar'])
      .sort({ createdAt: -1 });

    res.json(profiles);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

// @desc    Get profile by ID
// @route   GET /api/profiles/:id
// @access  Public
export const getProfileById = async (req, res) => {
  try {
    const profile = await Profile.findById(req.params.id).populate('user', ['name', 'avatar']);

    if (!profile) {
      return res.status(404).json({ error: 'Profile not found' });
    }

    res.json(profile);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};