import mongoose from 'mongoose';

const profileSchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  bio: {
    type: String,
    maxlength: [500, 'Bio cannot be more than 500 characters']
  },
  age: {
    type: Number,
    min: [18, 'Must be at least 18 years old']
  },
  gender: {
    type: String,
    enum: ['Male', 'Female', 'Non-binary', 'Prefer not to say']
  },
  occupation: {
    type: String
  },
  location: {
    city: {
      type: String,
      required: [true, 'City is required']
    },
    state: {
      type: String,
      required: [true, 'State is required']
    },
    country: {
      type: String,
      required: [true, 'Country is required']
    }
  },
  budget: {
    min: {
      type: Number,
      default: 0
    },
    max: {
      type: Number,
      required: [true, 'Maximum budget is required']
    }
  },
  moveInDate: {
    type: Date
  },
  preferences: {
    smoking: {
      type: Boolean,
      default: false
    },
    pets: {
      type: Boolean,
      default: false
    },
    drinking: {
      type: Boolean,
      default: false
    },
    cleanliness: {
      type: String,
      enum: ['Very clean', 'Clean', 'Average', 'Messy']
    },
    guestPreference: {
      type: String,
      enum: ['Frequently', 'Occasionally', 'Rarely', 'Never']
    },
    roommateGender: {
      type: [String],
      enum: ['Male', 'Female', 'Non-binary', 'No preference']
    }
  },
  lifestyle: {
    type: String,
    enum: ['Early bird', 'Night owl', 'Balanced']
  },
  photos: [{
    type: String
  }],
  active: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, {
  timestamps: true
});

profileSchema.index({ 'location.city': 1, 'location.state': 1 });
profileSchema.index({ 'budget.max': 1 });

const Profile = mongoose.model('Profile', profileSchema);

export default Profile;