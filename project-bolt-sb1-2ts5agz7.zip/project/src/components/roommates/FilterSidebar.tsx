import React from 'react';
import { Search, X } from 'lucide-react';

type FiltersType = {
  city: string;
  budget: string;
  gender: string;
  pets: boolean | undefined;
  smoking: boolean | undefined;
};

type FilterSidebarProps = {
  filters: FiltersType;
  onChange: (name: string, value: string | boolean) => void;
  onApply: () => void;
  onReset: () => void;
};

const FilterSidebar: React.FC<FilterSidebarProps> = ({ 
  filters, 
  onChange, 
  onApply, 
  onReset 
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-5 sticky top-24">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-lg font-semibold text-gray-900">Filters</h2>
        <button
          onClick={onReset}
          className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
        >
          <X className="h-4 w-4 mr-1" />
          Clear all
        </button>
      </div>
      
      <div className="space-y-6">
        {/* Search by city */}
        <div>
          <label htmlFor="city" className="block text-sm font-medium text-gray-700 mb-1">
            City
          </label>
          <div className="relative">
            <input
              type="text"
              id="city"
              placeholder="Enter city name"
              value={filters.city}
              onChange={(e) => onChange('city', e.target.value)}
              className="block w-full rounded-md border-gray-300 pl-10 pr-4 py-2 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            />
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-5 w-5 text-gray-400" />
            </div>
          </div>
        </div>
        
        {/* Budget range */}
        <div>
          <label htmlFor="budget" className="block text-sm font-medium text-gray-700 mb-1">
            Maximum Budget (per month)
          </label>
          <input
            type="number"
            id="budget"
            placeholder="Enter maximum budget"
            value={filters.budget}
            onChange={(e) => onChange('budget', e.target.value)}
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
          />
        </div>
        
        {/* Gender preference */}
        <div>
          <label htmlFor="gender" className="block text-sm font-medium text-gray-700 mb-1">
            Gender
          </label>
          <select
            id="gender"
            value={filters.gender}
            onChange={(e) => onChange('gender', e.target.value)}
            className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
          >
            <option value="">Any gender</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Non-binary">Non-binary</option>
          </select>
        </div>
        
        {/* Preferences section */}
        <div>
          <h3 className="text-sm font-medium text-gray-700 mb-3">Preferences</h3>
          
          <div className="space-y-2">
            <div className="flex items-center">
              <input
                type="checkbox"
                id="smoking"
                checked={filters.smoking === true}
                onChange={(e) => onChange('smoking', e.target.checked)}
                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <label htmlFor="smoking" className="ml-2 block text-sm text-gray-700">
                Smoking friendly
              </label>
            </div>
            
            <div className="flex items-center">
              <input
                type="checkbox"
                id="pets"
                checked={filters.pets === true}
                onChange={(e) => onChange('pets', e.target.checked)}
                className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <label htmlFor="pets" className="ml-2 block text-sm text-gray-700">
                Pet friendly
              </label>
            </div>
          </div>
        </div>
        
        {/* Apply filters button */}
        <button
          onClick={onApply}
          className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
          Apply Filters
        </button>
      </div>
    </div>
  );
};

export default FilterSidebar;