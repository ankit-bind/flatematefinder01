import React from 'react';
import { Link } from 'react-router-dom';
import { User, MapPin, DollarSign, Calendar } from 'lucide-react';
import { ProfileType } from '../../types';

type RoommateCardProps = {
  profile: ProfileType;
};

const RoommateCard: React.FC<RoommateCardProps> = ({ profile }) => {
  return (
    <Link to={`/profile/${profile._id}`}>
      <div className="bg-white rounded-lg shadow-md overflow-hidden transition-transform duration-300 hover:shadow-lg hover:-translate-y-1">
        <div className="p-4">
          <div className="flex items-center mb-4">
            <div className="bg-blue-100 p-2 rounded-full mr-3">
              <User className="h-8 w-8 text-blue-600" />
            </div>
            <div>
              <h3 className="font-medium text-gray-900">{profile.user.name}</h3>
              {profile.occupation && (
                <p className="text-gray-500 text-sm">{profile.occupation}</p>
              )}
            </div>
          </div>
          
          <div className="space-y-2 mb-4">
            <div className="flex items-start">
              <MapPin className="h-5 w-5 text-gray-400 mr-2 flex-shrink-0 mt-0.5" />
              <p className="text-gray-700">
                {profile.location.city}, {profile.location.state}, {profile.location.country}
              </p>
            </div>
            
            <div className="flex items-start">
              <DollarSign className="h-5 w-5 text-gray-400 mr-2 flex-shrink-0 mt-0.5" />
              <p className="text-gray-700">
                ${profile.budget.min || 0} - ${profile.budget.max} / month
              </p>
            </div>
            
            {profile.moveInDate && (
              <div className="flex items-start">
                <Calendar className="h-5 w-5 text-gray-400 mr-2 flex-shrink-0 mt-0.5" />
                <p className="text-gray-700">
                  Available from {new Date(profile.moveInDate).toLocaleDateString()}
                </p>
              </div>
            )}
          </div>
          
          <div className="flex flex-wrap gap-2 mb-4">
            {profile.preferences.smoking && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                Smoking friendly
              </span>
            )}
            {profile.preferences.pets && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                Pet friendly
              </span>
            )}
            {profile.lifestyle && (
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                {profile.lifestyle}
              </span>
            )}
          </div>
          
          <div className="text-sm text-gray-600 max-h-16 overflow-hidden">
            {profile.bio ? (
              <p>{profile.bio.length > 100 ? `${profile.bio.substring(0, 100)}...` : profile.bio}</p>
            ) : (
              <p>No bio provided.</p>
            )}
          </div>
        </div>
        
        <div className="bg-gray-50 px-4 py-3 border-t border-gray-100">
          <span className="text-blue-600 font-medium text-sm">View full profile →</span>
        </div>
      </div>
    </Link>
  );
};

export default RoommateCard;