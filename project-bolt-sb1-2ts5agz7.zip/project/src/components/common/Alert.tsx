import React from 'react';
import { AlertCircle, CheckCircle, Info, X } from 'lucide-react';

type AlertProps = {
  type: 'success' | 'error' | 'info' | 'warning';
  message: string;
  onClose?: () => void;
};

const Alert: React.FC<AlertProps> = ({ type, message, onClose }) => {
  const getAlertStyle = () => {
    switch (type) {
      case 'success':
        return {
          bgColor: 'bg-green-50',
          borderColor: 'border-green-400',
          textColor: 'text-green-700',
          icon: <CheckCircle className="h-5 w-5 text-green-400" />,
        };
      case 'error':
        return {
          bgColor: 'bg-red-50',
          borderColor: 'border-red-400',
          textColor: 'text-red-700',
          icon: <AlertCircle className="h-5 w-5 text-red-400" />,
        };
      case 'warning':
        return {
          bgColor: 'bg-yellow-50',
          borderColor: 'border-yellow-400',
          textColor: 'text-yellow-700',
          icon: <AlertCircle className="h-5 w-5 text-yellow-400" />,
        };
      case 'info':
      default:
        return {
          bgColor: 'bg-blue-50',
          borderColor: 'border-blue-400',
          textColor: 'text-blue-700',
          icon: <Info className="h-5 w-5 text-blue-400" />,
        };
    }
  };

  const { bgColor, borderColor, textColor, icon } = getAlertStyle();

  return (
    <div className={`${bgColor} border-l-4 ${borderColor} p-4 mb-4 rounded`}>
      <div className="flex">
        <div className="flex-shrink-0">{icon}</div>
        <div className={`ml-3 ${textColor}`}>
          <p className="text-sm">{message}</p>
        </div>
        {onClose && (
          <div className="ml-auto pl-3">
            <div className="-mx-1.5 -my-1.5">
              <button
                onClick={onClose}
                className={`inline-flex rounded-md p-1.5 ${textColor} hover:bg-opacity-20 focus:outline-none focus:ring-2 focus:ring-offset-2`}
              >
                <span className="sr-only">Dismiss</span>
                <X className="h-5 w-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Alert;