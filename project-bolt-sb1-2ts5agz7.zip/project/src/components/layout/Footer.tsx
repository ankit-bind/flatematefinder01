import React from 'react';
import { Link } from 'react-router-dom';
import { Github, Twitter, Facebook, Instagram, Home } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-800 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <Link to="/" className="text-white font-bold text-xl flex items-center">
              <Home className="h-6 w-6 mr-2" />
              RoommateFinder
            </Link>
            <p className="mt-3 text-gray-400">
              Find your perfect roommate match with our easy-to-use platform.
            </p>
            <div className="mt-4 flex space-x-4">
              <SocialLink href="#" icon={<Twitter className="h-5 w-5" />} />
              <SocialLink href="#" icon={<Facebook className="h-5 w-5" />} />
              <SocialLink href="#" icon={<Instagram className="h-5 w-5" />} />
              <SocialLink href="#" icon={<Github className="h-5 w-5" />} />
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <FooterLink to="/" label="Home" />
              </li>
              <li>
                <FooterLink to="/search" label="Find Roommates" />
              </li>
              <li>
                <FooterLink to="/login" label="Login" />
              </li>
              <li>
                <FooterLink to="/register" label="Sign Up" />
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <FooterLink to="#" label="Moving Tips" />
              </li>
              <li>
                <FooterLink to="#" label="Roommate Agreements" />
              </li>
              <li>
                <FooterLink to="#" label="Safety Guidelines" />
              </li>
              <li>
                <FooterLink to="#" label="FAQ" />
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              <li>
                <FooterLink to="#" label="Terms of Service" />
              </li>
              <li>
                <FooterLink to="#" label="Privacy Policy" />
              </li>
              <li>
                <FooterLink to="#" label="Cookie Policy" />
              </li>
              <li>
                <FooterLink to="#" label="Contact Us" />
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-gray-400">
          <p>© {new Date().getFullYear()} RoommateFinder. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

const FooterLink: React.FC<{ to: string; label: string }> = ({ to, label }) => {
  return (
    <Link to={to} className="text-gray-400 hover:text-white transition-colors duration-300">
      {label}
    </Link>
  );
};

const SocialLink: React.FC<{ href: string; icon: React.ReactNode }> = ({ href, icon }) => {
  return (
    <a 
      href={href} 
      className="text-gray-400 hover:text-white transition-colors duration-300"
      target="_blank"
      rel="noopener noreferrer"
    >
      {icon}
    </a>
  );
};

export default Footer;