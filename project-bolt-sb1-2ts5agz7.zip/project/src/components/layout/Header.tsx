import React, { useState, useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, X, User, LogIn, Home, Search, LogOut, UserPlus } from 'lucide-react';
import AuthContext from '../../context/AuthContext';

const Header: React.FC = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
    setMobileMenuOpen(false);
  };

  return (
    <header className="bg-white shadow-sm sticky top-0 z-10">
      <div className="container mx-auto px-4">
        <div className="flex justify-between h-16">
          <div className="flex">
            <div className="flex-shrink-0 flex items-center">
              <Link to="/" className="text-blue-600 font-bold text-xl flex items-center">
                <Home className="h-6 w-6 mr-2" />
                RoommateFinder
              </Link>
            </div>
            <nav className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <NavLink to="/" label="Home" />
              <NavLink to="/search" label="Find Roommates" />
              {user && <NavLink to="/dashboard" label="Dashboard" />}
            </nav>
          </div>
          <div className="hidden sm:ml-6 sm:flex sm:items-center sm:space-x-4">
            {user ? (
              <>
                <Link
                  to="/dashboard"
                  className="text-gray-500 hover:text-gray-700 px-3 py-2 rounded-md text-sm font-medium flex items-center"
                >
                  <User className="h-5 w-5 mr-1" />
                  {user.name.split(' ')[0]}
                </Link>
                <button
                  onClick={handleLogout}
                  className="bg-blue-600 text-white hover:bg-blue-700 px-3 py-2 rounded-md text-sm font-medium flex items-center"
                >
                  <LogOut className="h-4 w-4 mr-1" />
                  Logout
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="text-gray-500 hover:text-gray-700 px-3 py-2 rounded-md text-sm font-medium flex items-center"
                >
                  <LogIn className="h-4 w-4 mr-1" />
                  Login
                </Link>
                <Link
                  to="/register"
                  className="bg-blue-600 text-white hover:bg-blue-700 px-3 py-2 rounded-md text-sm font-medium flex items-center"
                >
                  <UserPlus className="h-4 w-4 mr-1" />
                  Sign Up
                </Link>
              </>
            )}
          </div>
          <div className="-mr-2 flex items-center sm:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:bg-gray-100 focus:text-gray-500"
            >
              <span className="sr-only">Open main menu</span>
              {mobileMenuOpen ? (
                <X className="block h-6 w-6" />
              ) : (
                <Menu className="block h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      <div className={`${mobileMenuOpen ? 'block' : 'hidden'} sm:hidden`}>
        <div className="pt-2 pb-3 space-y-1">
          <MobileNavLink to="/" label="Home" icon={<Home className="h-5 w-5 mr-2" />} onClick={() => setMobileMenuOpen(false)} />
          <MobileNavLink to="/search" label="Find Roommates" icon={<Search className="h-5 w-5 mr-2" />} onClick={() => setMobileMenuOpen(false)} />
          {user && (
            <MobileNavLink to="/dashboard" label="Dashboard" icon={<User className="h-5 w-5 mr-2" />} onClick={() => setMobileMenuOpen(false)} />
          )}
        </div>
        <div className="pt-4 pb-3 border-t border-gray-200">
          {user ? (
            <div className="space-y-1">
              <div className="px-4 py-2 text-gray-700 flex items-center">
                <User className="h-5 w-5 mr-2 text-gray-400" />
                <span className="font-medium">{user.name}</span>
              </div>
              <button
                onClick={handleLogout}
                className="block w-full text-left px-4 py-2 text-red-600 flex items-center hover:bg-gray-100"
              >
                <LogOut className="h-5 w-5 mr-2" />
                Logout
              </button>
            </div>
          ) : (
            <div className="space-y-1">
              <MobileNavLink to="/login" label="Login" icon={<LogIn className="h-5 w-5 mr-2" />} onClick={() => setMobileMenuOpen(false)} />
              <MobileNavLink to="/register" label="Sign Up" icon={<UserPlus className="h-5 w-5 mr-2" />} onClick={() => setMobileMenuOpen(false)} />
            </div>
          )}
        </div>
      </div>
    </header>
  );
};

const NavLink: React.FC<{ to: string; label: string }> = ({ to, label }) => {
  return (
    <Link
      to={to}
      className="text-gray-500 hover:text-gray-700 border-transparent hover:border-blue-500 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium"
    >
      {label}
    </Link>
  );
};

const MobileNavLink: React.FC<{ 
  to: string; 
  label: string; 
  icon: React.ReactNode;
  onClick: () => void;
}> = ({ to, label, icon, onClick }) => {
  return (
    <Link
      to={to}
      className="text-gray-600 hover:bg-gray-50 hover:text-gray-900 block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium flex items-center"
      onClick={onClick}
    >
      {icon}
      {label}
    </Link>
  );
};

export default Header;