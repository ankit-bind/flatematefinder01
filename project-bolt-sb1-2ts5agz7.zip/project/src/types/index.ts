export type User = {
  _id: string;
  name: string;
  email: string;
  avatar?: string;
};

export type ProfileType = {
  _id: string;
  user: User;
  bio?: string;
  age?: number;
  gender?: string;
  occupation?: string;
  location: {
    city: string;
    state: string;
    country: string;
  };
  budget: {
    min?: number;
    max: number;
  };
  moveInDate?: string;
  preferences: {
    smoking: boolean;
    pets: boolean;
    drinking: boolean;
    cleanliness?: string;
    guestPreference?: string;
    roommateGender?: string[];
  };
  lifestyle?: string;
  photos?: string[];
  active: boolean;
  createdAt: string;
  updatedAt?: string;
};