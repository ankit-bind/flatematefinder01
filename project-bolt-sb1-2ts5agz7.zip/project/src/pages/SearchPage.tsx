import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Search, Filter, X } from 'lucide-react';
import RoommateCard from '../components/roommates/RoommateCard';
import FilterSidebar from '../components/roommates/FilterSidebar';
import { ProfileType } from '../types';

const SearchPage: React.FC = () => {
  const [profiles, setProfiles] = useState<ProfileType[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  
  // Filter state
  const [filters, setFilters] = useState({
    city: '',
    budget: '',
    gender: '',
    pets: undefined as boolean | undefined,
    smoking: undefined as boolean | undefined,
  });

  // Load profiles on component mount
  useEffect(() => {
    fetchProfiles();
  }, []);

  const fetchProfiles = async (params = {}) => {
    setLoading(true);
    setError(null);
    
    try {
      const res = await axios.get('/api/profiles', { params });
      setProfiles(res.data);
      setLoading(false);
    } catch (err: any) {
      setError('Failed to load profiles. Please try again.');
      setLoading(false);
    }
  };

  const handleFilterChange = (name: string, value: string | boolean) => {
    setFilters({
      ...filters,
      [name]: value
    });
  };

  const applyFilters = () => {
    // Remove any undefined values
    const cleanFilters = Object.fromEntries(
      Object.entries(filters).filter(([_, v]) => v !== undefined && v !== '')
    );
    
    fetchProfiles(cleanFilters);
    if (window.innerWidth < 768) {
      setShowFilters(false);
    }
  };

  const resetFilters = () => {
    setFilters({
      city: '',
      budget: '',
      gender: '',
      pets: undefined,
      smoking: undefined,
    });
    fetchProfiles();
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Find Roommates</h1>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="md:hidden flex items-center px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-300"
        >
          {showFilters ? <X className="h-5 w-5" /> : <Filter className="h-5 w-5" />}
          <span className="ml-2">{showFilters ? 'Close' : 'Filters'}</span>
        </button>
      </div>

      {/* Mobile search bar */}
      <div className="md:hidden mb-6">
        <div className="relative">
          <input
            type="text"
            placeholder="Search by city..."
            value={filters.city}
            onChange={(e) => handleFilterChange('city', e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && applyFilters()}
            className="block w-full rounded-md border-gray-300 pl-10 pr-4 py-2 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
          />
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center">
            <Search className="h-5 w-5 text-gray-400" />
          </div>
        </div>
      </div>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Filter Sidebar - hidden on mobile unless toggled */}
        <div className={`${
          showFilters ? 'block' : 'hidden'
        } md:block w-full md:w-64 lg:w-80 flex-shrink-0`}>
          <FilterSidebar 
            filters={filters} 
            onChange={handleFilterChange}
            onApply={applyFilters}
            onReset={resetFilters}
          />
        </div>

        {/* Main content */}
        <div className="flex-1">
          {loading ? (
            <div className="flex justify-center items-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
            </div>
          ) : error ? (
            <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
              {error}
            </div>
          ) : profiles.length === 0 ? (
            <div className="bg-white rounded-lg shadow-md p-8 text-center">
              <div className="mx-auto flex items-center justify-center h-12 w-12 rounded-full bg-blue-100">
                <Search className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="mt-2 text-lg font-medium text-gray-900">No roommates found</h3>
              <p className="mt-1 text-sm text-gray-500">
                Try adjusting your filters or search criteria to find more results.
              </p>
              <div className="mt-6">
                <button
                  onClick={resetFilters}
                  className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                >
                  Reset Filters
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="mb-4 flex justify-between items-center">
                <p className="text-gray-600">{profiles.length} roommates found</p>
                {(filters.city || filters.budget || filters.gender || filters.pets !== undefined || filters.smoking !== undefined) && (
                  <button
                    onClick={resetFilters}
                    className="text-sm text-blue-600 hover:text-blue-800 flex items-center"
                  >
                    <X className="h-4 w-4 mr-1" />
                    Clear filters
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {profiles.map((profile) => (
                  <RoommateCard key={profile._id} profile={profile} />
                ))}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default SearchPage;