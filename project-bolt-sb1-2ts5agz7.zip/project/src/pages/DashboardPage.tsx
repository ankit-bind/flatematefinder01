import React, { useContext, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { User, Edit, Settings, LogOut, AlertCircle } from 'lucide-react';
import AuthContext from '../context/AuthContext';
import axios from 'axios';
import Alert from '../components/common/Alert';
import { ProfileType } from '../types';

const DashboardPage: React.FC = () => {
  const { user, logout } = useContext(AuthContext);
  const [profile, setProfile] = useState<ProfileType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await axios.get('/api/profiles/me');
        setProfile(res.data);
        setLoading(false);
      } catch (err: any) {
        if (err.response?.status === 404) {
          // Profile not found is not an error, just means user needs to create one
          setProfile(null);
        } else {
          setError('Failed to load your profile. Please try again.');
        }
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {/* Header Section */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 py-4">
            <div className="flex flex-col md:flex-row items-center justify-between">
              <div className="flex items-center mb-4 md:mb-0">
                <div className="bg-white p-2 rounded-full">
                  <User className="h-10 w-10 text-blue-600" />
                </div>
                <div className="ml-4 text-white">
                  <h1 className="text-xl font-bold">{user?.name}</h1>
                  <p className="text-blue-100">{user?.email}</p>
                </div>
              </div>
              <button
                onClick={logout}
                className="flex items-center px-4 py-2 bg-white text-blue-600 rounded-md hover:bg-blue-50 transition-colors duration-300"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Logout
              </button>
            </div>
          </div>

          {/* Main Content */}
          <div className="p-6">
            {error && <Alert type="error" message={error} />}

            {!profile ? (
              <div className="text-center py-8">
                <div className="bg-blue-100 text-blue-800 p-4 rounded-lg inline-flex items-center mb-6">
                  <AlertCircle className="h-5 w-5 mr-2" />
                  <span>You haven't created your roommate profile yet.</span>
                </div>
                <p className="text-gray-600 mb-6">
                  Create a profile to start finding your perfect roommate match!
                </p>
                <Link
                  to="/create-profile"
                  className="inline-flex items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-300"
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Create Your Profile
                </Link>
              </div>
            ) : (
              <div>
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-gray-800">Your Roommate Profile</h2>
                  <Link
                    to="/create-profile"
                    className="inline-flex items-center text-sm px-3 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-300"
                  >
                    <Edit className="h-4 w-4 mr-1" />
                    Edit Profile
                  </Link>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <ProfileSection title="Personal Information">
                    <ProfileItem label="Age" value={profile.age?.toString() || 'Not specified'} />
                    <ProfileItem label="Gender" value={profile.gender || 'Not specified'} />
                    <ProfileItem label="Occupation" value={profile.occupation || 'Not specified'} />
                    <ProfileItem label="Lifestyle" value={profile.lifestyle || 'Not specified'} />
                  </ProfileSection>

                  <ProfileSection title="Location & Budget">
                    <ProfileItem 
                      label="Location" 
                      value={profile.location ? 
                        `${profile.location.city}, ${profile.location.state}, ${profile.location.country}` : 
                        'Not specified'} 
                    />
                    <ProfileItem 
                      label="Budget" 
                      value={profile.budget ? 
                        `$${profile.budget.min} - $${profile.budget.max}` : 
                        'Not specified'} 
                    />
                    <ProfileItem 
                      label="Move-in Date" 
                      value={profile.moveInDate ? 
                        new Date(profile.moveInDate).toLocaleDateString() : 
                        'Not specified'} 
                    />
                  </ProfileSection>

                  <ProfileSection title="Preferences" className="md:col-span-2">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                      <PreferenceItem 
                        label="Smoking" 
                        value={profile.preferences?.smoking} 
                      />
                      <PreferenceItem 
                        label="Pets" 
                        value={profile.preferences?.pets} 
                      />
                      <PreferenceItem 
                        label="Drinking" 
                        value={profile.preferences?.drinking} 
                      />
                      <PreferenceItem 
                        label="Cleanliness" 
                        value={profile.preferences?.cleanliness} 
                        isText 
                      />
                      <PreferenceItem 
                        label="Guests" 
                        value={profile.preferences?.guestPreference} 
                        isText 
                      />
                    </div>
                  </ProfileSection>

                  <ProfileSection title="Bio" className="md:col-span-2">
                    <p className="text-gray-700">{profile.bio || 'No bio provided.'}</p>
                  </ProfileSection>
                </div>

                <div className="mt-8 pt-6 border-t border-gray-200">
                  <div className="flex justify-between items-center">
                    <h3 className="text-lg font-semibold text-gray-800">Profile Status</h3>
                    <div className={`px-3 py-1 rounded-full text-sm font-medium ${
                      profile.active ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {profile.active ? 'Active' : 'Inactive'}
                    </div>
                  </div>
                  <p className="text-gray-600 mt-2">
                    Your profile is {profile.active ? 'visible' : 'hidden'} to potential roommates.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Additional Dashboard Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          <DashboardCard
            title="Find Roommates"
            description="Browse potential roommates that match your criteria."
            icon={<Search className="h-6 w-6 text-blue-600" />}
            link="/search"
          />
          <DashboardCard
            title="Account Settings"
            description="Update your account information and preferences."
            icon={<Settings className="h-6 w-6 text-blue-600" />}
            link="#"
          />
          <DashboardCard
            title="Messages"
            description="View and respond to messages from potential roommates."
            icon={<MessageCircle className="h-6 w-6 text-blue-600" />}
            link="#"
          />
        </div>
      </div>
    </div>
  );
};

const ProfileSection: React.FC<{ 
  title: string; 
  children: React.ReactNode;
  className?: string;
}> = ({ title, children, className = '' }) => {
  return (
    <div className={`bg-gray-50 p-4 rounded-lg ${className}`}>
      <h3 className="text-lg font-semibold text-gray-800 mb-3">{title}</h3>
      <div className="space-y-2">
        {children}
      </div>
    </div>
  );
};

const ProfileItem: React.FC<{ label: string; value: string }> = ({ label, value }) => {
  return (
    <div className="flex justify-between">
      <span className="text-gray-600">{label}:</span>
      <span className="font-medium text-gray-900">{value}</span>
    </div>
  );
};

const PreferenceItem: React.FC<{ 
  label: string; 
  value?: boolean | string; 
  isText?: boolean;
}> = ({ label, value, isText = false }) => {
  if (isText) {
    return (
      <div className="bg-white p-3 rounded-md shadow-sm">
        <p className="text-sm text-gray-500">{label}</p>
        <p className="font-medium text-gray-900">{value || 'Not set'}</p>
      </div>
    );
  }

  return (
    <div className="bg-white p-3 rounded-md shadow-sm">
      <p className="text-sm text-gray-500">{label}</p>
      <div className={`mt-1 text-sm font-medium ${
        value ? 'text-green-600' : 'text-red-600'
      }`}>
        {value ? 'Yes' : 'No'}
      </div>
    </div>
  );
};

const DashboardCard: React.FC<{
  title: string;
  description: string;
  icon: React.ReactNode;
  link: string;
}> = ({ title, description, icon, link }) => {
  return (
    <Link 
      to={link} 
      className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 flex items-start"
    >
      <div className="mr-4">
        {icon}
      </div>
      <div>
        <h3 className="font-semibold text-gray-900">{title}</h3>
        <p className="text-gray-600 text-sm mt-1">{description}</p>
      </div>
    </Link>
  );
};

// Import these components to avoid errors
const Search: React.FC<{ className: string }> = ({ className }) => {
  return <lucide_react.Search className={className} />;
};

const MessageCircle: React.FC<{ className: string }> = ({ className }) => {
  return <lucide_react.MessageCircle className={className} />;
};

export default DashboardPage;