import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { User, MapPin, DollarSign, Calendar, ArrowLeft, Coffee, Moon } from 'lucide-react';
import axios from 'axios';
import { ProfileType } from '../types';

const ProfileDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [profile, setProfile] = useState<ProfileType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await axios.get(`/api/profiles/${id}`);
        setProfile(res.data);
        setLoading(false);
      } catch (err: any) {
        setError('Failed to load profile. Please try again.');
        setLoading(false);
      }
    };

    fetchProfile();
  }, [id]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
        </div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
          {error || 'Profile not found'}
        </div>
        <div className="mt-4">
          <Link to="/search" className="text-blue-600 hover:text-blue-800 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to search
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <Link to="/search" className="text-blue-600 hover:text-blue-800 flex items-center">
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to search
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 px-6 py-8 text-white">
            <div className="flex flex-col md:flex-row items-center md:items-start gap-6">
              <div className="bg-white p-3 rounded-full">
                <User className="h-16 w-16 text-blue-600" />
              </div>
              <div className="text-center md:text-left">
                <h1 className="text-2xl font-bold">{profile.user.name}</h1>
                <div className="flex flex-col md:flex-row items-center gap-3 mt-2">
                  <div className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span>{profile.location.city}, {profile.location.state}</span>
                  </div>
                  {profile.age && (
                    <div className="flex items-center">
                      <span className="hidden md:inline mx-2">•</span>
                      <span>{profile.age} years old</span>
                    </div>
                  )}
                  {profile.gender && (
                    <div className="flex items-center">
                      <span className="hidden md:inline mx-2">•</span>
                      <span>{profile.gender}</span>
                    </div>
                  )}
                </div>
                {profile.occupation && (
                  <p className="mt-1 text-blue-100">{profile.occupation}</p>
                )}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              {/* Budget & Move-in Date */}
              <div className="bg-blue-50 rounded-lg p-4">
                <h2 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                  <DollarSign className="h-5 w-5 mr-2 text-blue-600" />
                  Budget & Timing
                </h2>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Budget Range:</span>
                    <span className="font-medium text-gray-900">
                      ${profile.budget.min || 0} - ${profile.budget.max} / month
                    </span>
                  </div>
                  {profile.moveInDate && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Available From:</span>
                      <span className="font-medium text-gray-900">
                        {new Date(profile.moveInDate).toLocaleDateString()}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Lifestyle */}
              <div className="bg-purple-50 rounded-lg p-4">
                <h2 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                  {profile.lifestyle === 'Early bird' ? (
                    <Coffee className="h-5 w-5 mr-2 text-purple-600" />
                  ) : profile.lifestyle === 'Night owl' ? (
                    <Moon className="h-5 w-5 mr-2 text-purple-600" />
                  ) : (
                    <div className="h-5 w-5 mr-2 flex items-center justify-center text-purple-600">
                      <Coffee className="h-3 w-3" />
                      <Moon className="h-3 w-3" />
                    </div>
                  )}
                  Lifestyle
                </h2>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Lifestyle:</span>
                    <span className="font-medium text-gray-900">
                      {profile.lifestyle || 'Not specified'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Cleanliness:</span>
                    <span className="font-medium text-gray-900">
                      {profile.preferences.cleanliness || 'Not specified'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Guest Preference:</span>
                    <span className="font-medium text-gray-900">
                      {profile.preferences.guestPreference || 'Not specified'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Preferences Grid */}
            <div className="mb-8">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">Preferences</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
                <PreferenceCard 
                  title="Smoking" 
                  value={profile.preferences.smoking} 
                />
                <PreferenceCard 
                  title="Pets" 
                  value={profile.preferences.pets} 
                />
                <PreferenceCard 
                  title="Drinking" 
                  value={profile.preferences.drinking} 
                />
              </div>
            </div>

            {/* About Section */}
            <div className="mb-8">
              <h2 className="text-lg font-semibold text-gray-900 mb-3">About</h2>
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-gray-700">
                  {profile.bio || 'No bio provided.'}
                </p>
              </div>
            </div>

            {/* Contact Button */}
            <div className="flex justify-center mt-8">
              <button
                className="px-6 py-3 bg-blue-600 text-white font-medium rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
              >
                Contact {profile.user.name.split(' ')[0]}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const PreferenceCard: React.FC<{ title: string; value: boolean }> = ({ title, value }) => {
  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4 text-center">
      <h3 className="text-gray-600 text-sm mb-2">{title}</h3>
      <div className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
        value 
          ? 'bg-green-100 text-green-800' 
          : 'bg-red-100 text-red-800'
      }`}>
        {value ? 'Yes' : 'No'}
      </div>
    </div>
  );
};

export default ProfileDetailPage;