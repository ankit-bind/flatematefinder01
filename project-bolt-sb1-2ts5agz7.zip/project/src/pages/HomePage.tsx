import React from 'react';
import { Link } from 'react-router-dom';
import { Home, Search, UserPlus, DollarSign } from 'lucide-react';

const HomePage: React.FC = () => {
  return (
    <div className="bg-gradient-to-b from-blue-50 to-white">
      {/* Hero Section */}
      <section className="relative px-4 py-20 sm:px-6 lg:px-8 lg:py-32 overflow-hidden">
        <div className="container mx-auto text-center">
          <h1 className="text-4xl font-bold tracking-tight text-gray-900 sm:text-5xl md:text-6xl">
            <span className="block text-blue-600">Find Your Ideal</span>
            <span className="block">Roommate</span>
          </h1>
          <p className="mx-auto mt-5 max-w-xl text-xl text-gray-500">
            Connect with compatible roommates, share expenses, and make your living situation better.
          </p>
          <div className="mt-8 flex justify-center gap-4">
            <Link
              to="/search"
              className="rounded-md bg-blue-600 px-5 py-3 text-lg font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300"
            >
              Find Roommates
            </Link>
            <Link
              to="/register"
              className="rounded-md bg-white px-5 py-3 text-lg font-medium text-blue-600 shadow-sm ring-1 ring-blue-600 hover:bg-blue-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-all duration-300"
            >
              List Yourself
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            How It Works
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <FeatureCard 
              icon={<UserPlus className="h-8 w-8 text-blue-600" />}
              title="Create a Profile"
              description="Sign up and create your profile with your preferences and requirements."
            />
            <FeatureCard 
              icon={<Search className="h-8 w-8 text-blue-600" />}
              title="Search Roommates"
              description="Browse through potential roommates filtered by location, budget, and lifestyle."
            />
            <FeatureCard 
              icon={<Home className="h-8 w-8 text-blue-600" />}
              title="Connect"
              description="Message potential roommates and schedule meetings to find the right match."
            />
            <FeatureCard 
              icon={<DollarSign className="h-8 w-8 text-blue-600" />}
              title="Save Money"
              description="Split rent and utilities to make housing more affordable."
            />
          </div>
        </div>
      </section>

      {/* Testimonial Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">
            Success Stories
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <TestimonialCard 
              quote="I found my roommate within a week! The filtering options made it easy to find someone compatible with my lifestyle."
              author="Sarah J."
              location="New York, NY"
            />
            <TestimonialCard 
              quote="As a student moving to a new city, this platform helped me find not just a roommate but a friend. Highly recommend!"
              author="Michael T."
              location="Chicago, IL"
            />
            <TestimonialCard 
              quote="The detailed profiles helped me find someone who matched my cleanliness standards and work schedule. Very happy!"
              author="Jessica K."
              location="San Francisco, CA"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-blue-600">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Ready to Find Your Ideal Roommate?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Join thousands of users who have successfully found compatible roommates through our platform.
          </p>
          <Link
            to="/register"
            className="inline-block rounded-md bg-white px-6 py-3 text-lg font-medium text-blue-600 shadow-md hover:bg-blue-50 focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-blue-600 transition-all duration-300"
          >
            Get Started Now
          </Link>
        </div>
      </section>
    </div>
  );
};

const FeatureCard: React.FC<{ icon: React.ReactNode, title: string, description: string }> = ({ 
  icon, 
  title, 
  description 
}) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md text-center transform hover:scale-105 transition-all duration-300">
      <div className="inline-flex items-center justify-center p-3 bg-blue-100 rounded-full mb-4">
        {icon}
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mb-2">{title}</h3>
      <p className="text-gray-600">{description}</p>
    </div>
  );
};

const TestimonialCard: React.FC<{ quote: string, author: string, location: string }> = ({ 
  quote, 
  author, 
  location 
}) => {
  return (
    <div className="bg-white p-6 rounded-lg shadow-md">
      <p className="text-gray-600 italic mb-4">"{quote}"</p>
      <div>
        <p className="font-semibold text-gray-900">{author}</p>
        <p className="text-gray-500 text-sm">{location}</p>
      </div>
    </div>
  );
};

export default HomePage;