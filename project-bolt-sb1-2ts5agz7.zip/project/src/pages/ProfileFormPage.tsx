import React, { useState, useEffect, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { Save, ArrowLeft } from 'lucide-react';
import axios from 'axios';
import Alert from '../components/common/Alert';
import AuthContext from '../context/AuthContext';

const ProfileFormPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [editMode, setEditMode] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState({
    bio: '',
    age: '',
    gender: '',
    occupation: '',
    location: {
      city: '',
      state: '',
      country: ''
    },
    budget: {
      min: '',
      max: ''
    },
    moveInDate: '',
    preferences: {
      smoking: false,
      pets: false,
      drinking: false,
      cleanliness: '',
      guestPreference: ''
    },
    lifestyle: '',
    photos: [''],
    active: true
  });

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await axios.get('/api/profiles/me');
        if (res.data) {
          setFormData({
            ...res.data,
            age: res.data.age?.toString() || '',
            budget: {
              min: res.data.budget?.min?.toString() || '',
              max: res.data.budget?.max?.toString() || ''
            },
            moveInDate: res.data.moveInDate ? 
              new Date(res.data.moveInDate).toISOString().split('T')[0] : ''
          });
          setEditMode(true);
        }
      } catch (err) {
        // Profile doesn't exist, continue in create mode
        setEditMode(false);
      }
    };

    fetchProfile();
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData({
        ...formData,
        [parent]: {
          ...formData[parent as keyof typeof formData] as Record<string, any>,
          [child]: value
        }
      });
    } else {
      setFormData({
        ...formData,
        [name]: value
      });
    }
  };

  const handleCheckboxChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, checked } = e.target;
    
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setFormData({
        ...formData,
        [parent]: {
          ...formData[parent as keyof typeof formData] as Record<string, any>,
          [child]: checked
        }
      });
    } else {
      setFormData({
        ...formData,
        [name]: checked
      });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    
    try {
      // Format the data for API
      const profileData = {
        ...formData,
        age: formData.age ? parseInt(formData.age) : undefined,
        budget: {
          min: formData.budget.min ? parseInt(formData.budget.min) : 0,
          max: formData.budget.max ? parseInt(formData.budget.max) : undefined
        }
      };
      
      await axios.post('/api/profiles', profileData);
      
      setSuccess(true);
      setLoading(false);
      
      // Redirect to dashboard after successful submission
      setTimeout(() => {
        navigate('/dashboard');
      }, 1500);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to save profile. Please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <div className="mb-6 flex items-center">
          <button 
            onClick={() => navigate('/dashboard')}
            className="mr-4 flex items-center text-blue-600 hover:text-blue-800"
          >
            <ArrowLeft className="h-4 w-4 mr-1" />
            Back to Dashboard
          </button>
          <h1 className="text-2xl font-bold text-gray-900">
            {editMode ? 'Edit Your Profile' : 'Create Your Profile'}
          </h1>
        </div>

        {error && <Alert type="error" message={error} />}
        {success && <Alert type="success" message="Profile saved successfully!" />}
        
        <div className="bg-white rounded-lg shadow-md p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Personal Information Section */}
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Personal Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="age" className="block text-sm font-medium text-gray-700 mb-1">
                    Age
                  </label>
                  <input
                    type="number"
                    id="age"
                    name="age"
                    min="18"
                    value={formData.age}
                    onChange={handleChange}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                
                <div>
                  <label htmlFor="gender" className="block text-sm font-medium text-gray-700 mb-1">
                    Gender
                  </label>
                  <select
                    id="gender"
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  >
                    <option value="">Select gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Non-binary">Non-binary</option>
                    <option value="Prefer not to say">Prefer not to say</option>
                  </select>
                </div>
                
                <div>
                  <label htmlFor="occupation" className="block text-sm font-medium text-gray-700 mb-1">
                    Occupation
                  </label>
                  <input
                    type="text"
                    id="occupation"
                    name="occupation"
                    value={formData.occupation}
                    onChange={handleChange}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                
                <div>
                  <label htmlFor="lifestyle" className="block text-sm font-medium text-gray-700 mb-1">
                    Lifestyle
                  </label>
                  <select
                    id="lifestyle"
                    name="lifestyle"
                    value={formData.lifestyle}
                    onChange={handleChange}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  >
                    <option value="">Select lifestyle</option>
                    <option value="Early bird">Early bird</option>
                    <option value="Night owl">Night owl</option>
                    <option value="Balanced">Balanced</option>
                  </select>
                </div>
              </div>
            </section>
            
            {/* Location & Budget Section */}
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Location & Budget</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <label htmlFor="location.city" className="block text-sm font-medium text-gray-700 mb-1">
                    City
                  </label>
                  <input
                    type="text"
                    id="location.city"
                    name="location.city"
                    value={formData.location.city}
                    onChange={handleChange}
                    required
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                
                <div>
                  <label htmlFor="location.state" className="block text-sm font-medium text-gray-700 mb-1">
                    State/Province
                  </label>
                  <input
                    type="text"
                    id="location.state"
                    name="location.state"
                    value={formData.location.state}
                    onChange={handleChange}
                    required
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                
                <div>
                  <label htmlFor="location.country" className="block text-sm font-medium text-gray-700 mb-1">
                    Country
                  </label>
                  <input
                    type="text"
                    id="location.country"
                    name="location.country"
                    value={formData.location.country}
                    onChange={handleChange}
                    required
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label htmlFor="budget.min" className="block text-sm font-medium text-gray-700 mb-1">
                    Min Budget ($)
                  </label>
                  <input
                    type="number"
                    id="budget.min"
                    name="budget.min"
                    min="0"
                    value={formData.budget.min}
                    onChange={handleChange}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                
                <div>
                  <label htmlFor="budget.max" className="block text-sm font-medium text-gray-700 mb-1">
                    Max Budget ($)
                  </label>
                  <input
                    type="number"
                    id="budget.max"
                    name="budget.max"
                    min="0"
                    value={formData.budget.max}
                    onChange={handleChange}
                    required
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
                
                <div>
                  <label htmlFor="moveInDate" className="block text-sm font-medium text-gray-700 mb-1">
                    Move-in Date
                  </label>
                  <input
                    type="date"
                    id="moveInDate"
                    name="moveInDate"
                    value={formData.moveInDate}
                    onChange={handleChange}
                    className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  />
                </div>
              </div>
            </section>
            
            {/* Preferences Section */}
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-4">Preferences</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="preferences.smoking"
                      name="preferences.smoking"
                      checked={formData.preferences.smoking}
                      onChange={handleCheckboxChange}
                      className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <label htmlFor="preferences.smoking" className="ml-2 block text-sm text-gray-700">
                      Smoking friendly
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="preferences.pets"
                      name="preferences.pets"
                      checked={formData.preferences.pets}
                      onChange={handleCheckboxChange}
                      className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <label htmlFor="preferences.pets" className="ml-2 block text-sm text-gray-700">
                      Pets allowed
                    </label>
                  </div>
                  
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      id="preferences.drinking"
                      name="preferences.drinking"
                      checked={formData.preferences.drinking}
                      onChange={handleCheckboxChange}
                      className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                    />
                    <label htmlFor="preferences.drinking" className="ml-2 block text-sm text-gray-700">
                      Drinking friendly
                    </label>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label htmlFor="preferences.cleanliness" className="block text-sm font-medium text-gray-700 mb-1">
                      Cleanliness Preference
                    </label>
                    <select
                      id="preferences.cleanliness"
                      name="preferences.cleanliness"
                      value={formData.preferences.cleanliness}
                      onChange={handleChange}
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    >
                      <option value="">Select preference</option>
                      <option value="Very clean">Very clean</option>
                      <option value="Clean">Clean</option>
                      <option value="Average">Average</option>
                      <option value="Messy">Messy</option>
                    </select>
                  </div>
                  
                  <div>
                    <label htmlFor="preferences.guestPreference" className="block text-sm font-medium text-gray-700 mb-1">
                      Guest Preference
                    </label>
                    <select
                      id="preferences.guestPreference"
                      name="preferences.guestPreference"
                      value={formData.preferences.guestPreference}
                      onChange={handleChange}
                      className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                    >
                      <option value="">Select preference</option>
                      <option value="Frequently">Frequently</option>
                      <option value="Occasionally">Occasionally</option>
                      <option value="Rarely">Rarely</option>
                      <option value="Never">Never</option>
                    </select>
                  </div>
                </div>
              </div>
            </section>
            
            {/* Bio Section */}
            <section>
              <h2 className="text-xl font-semibold text-gray-800 mb-4">About You</h2>
              <div>
                <label htmlFor="bio" className="block text-sm font-medium text-gray-700 mb-1">
                  Bio (Max 500 characters)
                </label>
                <textarea
                  id="bio"
                  name="bio"
                  rows={5}
                  maxLength={500}
                  value={formData.bio}
                  onChange={handleChange}
                  className="block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                  placeholder="Tell potential roommates about yourself..."
                ></textarea>
                <p className="mt-1 text-sm text-gray-500">{formData.bio.length}/500 characters</p>
              </div>
            </section>
            
            {/* Profile Visibility */}
            <section>
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="active"
                  name="active"
                  checked={formData.active}
                  onChange={handleCheckboxChange}
                  className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                />
                <label htmlFor="active" className="ml-2 block text-sm text-gray-700">
                  Make my profile visible to others
                </label>
              </div>
            </section>
            
            {/* Submit Button */}
            <div className="pt-4 border-t border-gray-200">
              <button
                type="submit"
                disabled={loading}
                className="flex items-center justify-center w-full sm:w-auto px-6 py-3 bg-blue-600 text-white font-medium rounded-md shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-75 disabled:hover:bg-blue-600"
              >
                <Save className="mr-2 h-5 w-5" />
                {loading ? 'Saving...' : 'Save Profile'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ProfileFormPage;